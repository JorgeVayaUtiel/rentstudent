const User = require('../models/User');
exports.registerUser = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const user = await User.create({
      name,
      email,
      passwordHash: password,
      role
    });
    res.status(201).json(user);
  } catch (error) {
    res.status(500).json({ error: 'Registration failed', details: error.message });
  }
};
