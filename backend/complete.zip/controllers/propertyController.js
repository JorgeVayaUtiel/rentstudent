// Placeholder property controller
exports.placeholder = (req, res) => {
  res.json({ message: 'Property controller ready' });
};
