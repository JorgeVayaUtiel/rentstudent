export default function App() {
  return (
    <div>
      <h1>Bienvenido a RentStudent</h1>
    </div>
  );
}
