# RentStudent Frontend

Proyecto frontend funcional para rentstudent.net