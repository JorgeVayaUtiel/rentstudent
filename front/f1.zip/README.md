# RentStudent Frontend (corregido)

Este proyecto está listo para ser compilado y desplegado.